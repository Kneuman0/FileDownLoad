package com.zeva.temp.dataModellib;

import java.util.List;

import com.zeva.temp.dataModellib.AddressBean;

public class ProviderList{
	String name;
	String language;
	String tspInformationURI;
	AddressBean address;
	List<ServiceBean> tspServices;
	
	
	/**
	 * @return the tspInformationURI
	 */
	public String getTspInformationURI() {
		return tspInformationURI;
	}
	/**
	 * @param tspInformationURI the tspInformationURI to set
	 */
	public void setTspInformationURI(String tspInformationURI) {
		this.tspInformationURI = tspInformationURI;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}
	/**
	 * @param language the language to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}
	/**
	 * @return the address
	 */
	public AddressBean getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(AddressBean address) {
		this.address = address;
	}
	/**
	 * @return the tspServices
	 */
	public List<ServiceBean> getTspServices() {
		return tspServices;
	}
	/**
	 * @param tspServices the tspServices to set
	 */
	public void setTspServices(List<ServiceBean> tspServices) {
		this.tspServices = tspServices;
	}
	
	
}
