package com.zeva.temp.dataModellib;

public interface TLAttribute {
	
	String nameProperty();
}
