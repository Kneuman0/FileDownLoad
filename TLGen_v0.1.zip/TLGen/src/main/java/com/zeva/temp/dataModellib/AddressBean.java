package com.zeva.temp.dataModellib;

import java.util.ArrayList;
import java.util.List;

public class AddressBean {
	List<PhysicalAddressBean> physAddr;
	
	List<ElectronicAddressBean> elecAddr;
	
	public AddressBean(){
		physAddr = new ArrayList<>();
		elecAddr = new ArrayList<>();
	}
	
	public AddressBean(String physAddresses, String elecAddresses){
		physAddr = new ArrayList<>();
		elecAddr = new ArrayList<>();
		
		String[] pAddresses = physAddresses.split(",");
		String[] eAddresses = elecAddresses.split(",");
		for(String single : pAddresses)
			physAddr.add(new PhysicalAddressBean(single));
		
		for(String uri : eAddresses)
			elecAddr.add(new ElectronicAddressBean(uri));
	}
	
	public void addPhysAddress(PhysicalAddressBean addr){
		physAddr.add(addr);
	}
	
	public void addElecAddress(ElectronicAddressBean electronicAddr){
		elecAddr.add(electronicAddr);
	}

	/**
	 * @return the physAddr
	 */
	public List<PhysicalAddressBean> getPhysAddr() {
		return physAddr;
	}

	/**
	 * @param physAddr the physAddr to set
	 */
	public void setPhysAddr(List<PhysicalAddressBean> physAddr) {
		this.physAddr = physAddr;
	}

	/**
	 * @return the elecAddr
	 */
	public List<ElectronicAddressBean> getElecAddr() {
		return elecAddr;
	}

	/**
	 * @param elecAddr the elecAddr to set
	 */
	public void setElecAddr(List<ElectronicAddressBean> elecAddr) {
		this.elecAddr = elecAddr;
	}
	
	
	
	
}
