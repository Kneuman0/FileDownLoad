package com.zeva.temp.dataModellib;

public class SchemeTypeCommunityRules {
	private String lang;
	private String uri;
}
