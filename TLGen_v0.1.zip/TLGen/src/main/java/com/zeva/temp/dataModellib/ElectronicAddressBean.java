package com.zeva.temp.dataModellib;

public class ElectronicAddressBean {
	
	private String uri;
	
	public ElectronicAddressBean(String uri){
		this.uri = uri;
	}
	
	public ElectronicAddressBean(){}

	/**
	 * @return the uri
	 */
	public String getUri() {
		return uri;
	}

	/**
	 * @param uri the uri to set
	 */
	public void setUri(String uri) {
		this.uri = uri;
	}
	
	

}
