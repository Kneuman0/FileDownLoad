package com.zeva.temp.dataModellib;

import javafx.beans.property.SimpleStringProperty;

public class SettingBean {
	
	private SimpleStringProperty name;
	
	private String value;
	
	public SettingBean(String name, String value){
		this.name = new SimpleStringProperty(name);
		this.value = value;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name.get();
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = new SimpleStringProperty(name);
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
	
	public SimpleStringProperty nameProperty(){
		return name;
	}

}
