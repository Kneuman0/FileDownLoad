package com.zeva.temp.dataModellib;

public class SchemeOperatorName {
	
	private String language;
	private String name;

}
