package com.zeva.tlGen.controllers;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;

import com.zeva.temp.dataModellib.SettingBean;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

public class DefaultSettingsController {

    @FXML
    private TextArea settingDisplayArea;

    @FXML
    private TableView<SettingBean> settingsTable;

    @FXML
    private Button saveButton;
    
    @FXML
    private TableColumn<SettingBean, String> settingCol;
    
    private Properties props;
	
	
	public void initialize(){
		initializeSettingTable();
	}
	
	public void onSelectSetting(MouseEvent event){
		SettingBean bean = settingsTable.getSelectionModel().getSelectedItem();
		settingDisplayArea.setText(bean.getValue());
	}
	
	public void onSaveSettingButton(){
		SettingBean selectedBean = settingsTable.getSelectionModel().getSelectedItem();
		selectedBean.setValue(settingDisplayArea.getText());
		props.setProperty(selectedBean.getName(), selectedBean.getValue());
		
		try(FileOutputStream out = new FileOutputStream("props.settings")){
			props.store(out, null);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void initializeSettingTable(){
		settingCol.setCellValueFactory(new PropertyValueFactory<SettingBean, String>("name"));
		settingsTable.setItems(getSettingBeans());
		
	}
	
	private ObservableList<SettingBean> getSettingBeans(){
		initProps();
		
		ObservableList<SettingBean> beans = FXCollections.<SettingBean>observableArrayList();
		Enumeration<?> propertiesSet = props.propertyNames();
		while(propertiesSet.hasMoreElements()){
			String key = (String)propertiesSet.nextElement();
			beans.add(new SettingBean(key, props.getProperty(key)));
		}
		
		return beans;
	}
	
	private void initProps(){
		props = new Properties();
		try (FileInputStream stream = new FileInputStream("props.settings");){
			props.load(stream);
		} catch (IOException e) {
			Alert warning = new Alert(AlertType.ERROR);
			warning.setTitle("Settings Load Failure");
			warning.setHeaderText("The file 'props.settings' has either been removed or\n"
					+ "renamed. Setting could not be loaded");
			warning.setContentText(null);
			warning.showAndWait();
		}
	}

}
