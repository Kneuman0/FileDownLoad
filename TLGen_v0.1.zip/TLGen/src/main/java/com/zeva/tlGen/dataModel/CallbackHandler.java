package com.zeva.tlGen.dataModel;

import com.zeva.tlGen.controllers.CellValueMaker;

import javafx.scene.control.TreeTableCell;
import javafx.scene.control.TreeTableColumn;
import javafx.util.Callback;

public class CallbackHandler implements Callback<TreeTableColumn<CertificateBean, CertificateBean>,
													TreeTableCell<CertificateBean, CertificateBean>>{

	@Override
	public TreeTableCell<CertificateBean, CertificateBean> call(
			TreeTableColumn<CertificateBean, CertificateBean> param) {
		return new CellValueMaker();
	}

}
