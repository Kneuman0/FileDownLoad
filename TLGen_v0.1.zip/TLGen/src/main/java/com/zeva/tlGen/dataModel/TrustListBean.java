package com.zeva.tlGen.dataModel;

import javafx.beans.property.SimpleStringProperty;

import com.zeva.temp.dataModellib.TrustList;

public class TrustListBean extends TrustList {
	
	private SimpleStringProperty name;
	
	private TrustList parent;
	
	public TrustListBean(TrustList list){
		this.parent = list;
		this.name = new SimpleStringProperty(
				list.getStatusInfo().getSchemeOperatorName() == null ||
				list.getStatusInfo().getSchemeOperatorName() == ""
				? "No SchemeOperatorName" : list.getStatusInfo().getSchemeOperatorName());
	}
	
	/**
	 * Use only for root in Table Tree View
	 * @param name
	 */
	public TrustListBean(String name){
		this.name = new SimpleStringProperty(name);
	}

	/**
	 * @return the parent
	 */
	public TrustList getParent() {
		return parent;
	}

	/**
	 * @param parent the parent to set
	 */
	public void setParent(TrustList parent) {
		this.parent = parent;
	}

	/**
	 * @return the name
	 */
	public SimpleStringProperty nameProperty() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = new SimpleStringProperty(name);
	}
	
	@Override
	public String toString(){
		return "What info needs to be displayed here?";
	}
	
	

}
