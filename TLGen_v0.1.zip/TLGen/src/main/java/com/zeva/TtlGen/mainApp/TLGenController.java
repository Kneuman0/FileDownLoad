package com.zeva.TtlGen.mainApp;

import java.io.File;
import java.io.IOException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import javax.xml.crypto.dsig.XMLSignatureException;

import com.sun.org.apache.xml.internal.security.exceptions.Base64DecodingException;
import com.zeva.TtlGen.utils.CertificateEncapsulater;
import com.zeva.TtlGen.utils.CertificateUtilities;
import com.zeva.temp.dataModellib.TrustList;
import com.zeva.tlGen.controllers.CellValueMaker;
import com.zeva.tlGen.dataModel.CallbackHandler;
import com.zeva.tlGen.dataModel.CertificateBean;
import com.zeva.tlGen.dataModel.TrustListBean;

import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableView;
import javafx.scene.control.cell.TreeItemPropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.WindowEvent;
import javafx.stage.FileChooser.ExtensionFilter;

public class TLGenController {
	
    @FXML
    private TreeTableView<CertificateBean> tlCertsTree, uploadedCertsTree;

    @FXML
    private TreeTableColumn<CertificateBean, CertificateBean> uploadedCertsTreeCol, tlCertsTreeCol;
    
    @FXML
    private TreeTableColumn<TrustListBean, CertificateBean> trustListsCol, listOfListsCol;
    
    @FXML
    private TreeTableView<TrustListBean> trustLists, listOfLists;

    @FXML
    private TextArea textArea, textArea1;
    
    @FXML
    private TabPane tabPane;
    
    @FXML
    private GridPane listOfListGridPane, tlGridPane;	
    	
	public void initialize(){
		
		// Remove me!
		listOfListGridPane.setDisable(true);
		
		try {
			Thread.sleep(3 * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		setBackgroundImages();
		initializeTreeTables();
		setTabPaneBackground();
	}
	
	/*****************************************************************************
	 * 																			 *
	 * 																			 *
	 * 							First Tab Listeners								 *
	 * 																			 *
	 *																			 *
	 *****************************************************************************/
	
	public void exportCertsToPemListener(){
		List<TreeItem<CertificateBean>> tlCerts = tlCertsTree.getRoot().getChildren();
		if(tlCerts == null || tlCerts.size() == 0) return;
		
		FileChooser chooser = new FileChooser();
		chooser.setTitle("PEM File Location");
		chooser.setInitialFileName("TestMe");
		
		chooser.getExtensionFilters().add(
				new ExtensionFilter("Privacy Enhanced Mail", "*.pem"));
		
		File certFile = chooser.showSaveDialog(tlGridPane.getScene()
				.getWindow());

		// if null, user clicked cancel so do nothing
		if (certFile == null) {
			return;
		} else {
			try {
				CertificateUtilities.exportNodesToPem(
						tlCertsTree.getRoot().getChildren(), certFile);
			} catch (IOException e) {
				String header = "An error occured while exporting the .pem file";
				displayErrorMessage("Export Error", header,	null, e);
			} catch (CertificateEncodingException e) {
				String header = "An error occured while exporting the .pem file";
				displayErrorMessage("Export Error", header,	null, e);
			}
		}
		
		
	}
	
	public void importTrustListListener(){		
		FileChooser chooser = new FileChooser();
		chooser.setTitle("Excel File Location");
		chooser.setInitialFileName("TestMe");
		
		chooser.getExtensionFilters().add(
				new ExtensionFilter("XML Document", "*.xml"));
		
		List<File> trustLists = chooser.showOpenMultipleDialog(tlGridPane.getScene()
				.getWindow());

		// if null, user clicked cancel so do nothing
		if (trustLists == null) {
			return;
		} else {
			for(File tl : trustLists){
				try {
								
					addCertsToTree(CertificateUtilities.getUnmarshalledCertsFromTL(tl));
					
					
				} catch(XMLSignatureException sigError){
					String title = "Upload Error";
					String header = "An error occured while reading one or more files\n"
							+ "Error: " + sigError.getMessage();
					displayErrorMessage(title, header, null, sigError);
				} catch(Exception error){
					String title = "Upload Error";
					String header = "An error occured while reading one or more files\n"
							+ "Error: " + error.getMessage();
					displayErrorMessage(title, header, null, error);
				}
				
			}
			
		}
	}
	
	public void addCertsToTrustListButton(){
		ObservableList<TreeItem<CertificateBean>> chosenCerts = 
		uploadedCertsTree.getSelectionModel().getSelectedItems();
		tlCertsTree.getRoot().getChildren().addAll(chosenCerts);
	}
	
	public void onButtonMoveUp(){
		
	}
	
	public void onButtonMoveDown(){
		
	}
	
	public void onExportTl(){
		FileChooser chooser = new FileChooser();
		chooser.setTitle("XML Trust List File Location");
		chooser.setInitialFileName("TestMe");
		
		chooser.getExtensionFilters().add(
				new ExtensionFilter("XML Document", "*.xml"));
		
		File certFile = chooser.showSaveDialog(tlGridPane.getScene()
				.getWindow());

		// if null, user clicked cancel so do nothing
		if (certFile == null) {
			return;
		} else {
			List<CertificateBean> beans = new ArrayList<CertificateBean>();
			List<TreeItem<CertificateBean>> nodes = tlCertsTree.getRoot().getChildren();
			if(nodes == null) return;
			for(TreeItem<CertificateBean> bean : nodes){
				beans.add(bean.getValue());
			}
			
			// Need to make password popup
			TrustList tl = CertificateUtilities.buildTrustList(beans);
			try {
				CertificateUtilities.exportTL("password", tl, certFile);
			} catch (IOException e) {
				String header = "An error occured while exporting the trust list";
				displayErrorMessage("Export Error", header,	null, e);
			}
		}
	}
	
	public void onDeleteCerts(KeyEvent event){
		if(event.getCode() == KeyCode.DELETE || event.getCode() == KeyCode.BACK_SPACE){
			@SuppressWarnings("unchecked")
			TreeTableView<Object> bean = (TreeTableView<Object>)event.getSource();
			Alert ensureDelete = new Alert(AlertType.CONFIRMATION);
			ensureDelete.setTitle("Confirm Delete");
			ensureDelete.setHeaderText("Deleting cannot be undone, are you sure you\n"
					+ "want to delete the highlighted certificates?");
			ensureDelete.setContentText(null);
			Optional<ButtonType> optional = ensureDelete.showAndWait();
			if(optional.get() == ButtonType.OK){
				CertificateUtilities.deleteSelectedItems(bean.getRoot().getChildren(),
						bean.getSelectionModel().getSelectedItems());
			}else{
				return;
			}
		}
		
	}
	
	public void importCertificatesButtonListener(){
		FileChooser chooser = new FileChooser();
		chooser.setTitle("Excel File Location");
		chooser.setInitialFileName("TestMe");
		
		chooser.getExtensionFilters().addAll(
				CertificateUtilities.getSupportedExtFilters());
		
		List<File> certFiles = chooser.showOpenMultipleDialog(tlGridPane.getScene()
				.getWindow());

		// if null, user clicked cancel so do nothing
		if (certFiles == null) {
			return;
		} else {
			for(File certFile : certFiles){
				try {

					CertificateEncapsulater encap = new CertificateEncapsulater(certFile);
					addCertsToTree(encap.getEncapulatedCerts());
					
				} catch (CertificateException | Base64DecodingException
						| IOException e) {
					String title = "Upload Error";
					String header = "An error occured while reading one or more files\n"
							+ "Error: " + e.getMessage();
					displayErrorMessage(title, header, null, e);
				} 
				
			}
			
		}
	}
	
	public void onSettingMenuSelected(){
		Stage stage = new Stage();
		stage.initStyle(StageStyle.UTILITY);
		FXMLLoader loader = null;
		Parent parent = null;
		try {
			loader = new FXMLLoader(getClass().getResource(
					"/resources/SettingsGUI.fxml"));
			
			parent = (Parent) loader.load();

		} catch (IOException e) {
			e.printStackTrace();
		}
		Scene scene = new Scene(parent);

		// window title
		stage.setTitle("Default Trust List Settings");
		stage.setScene(scene);
		stage.show();
	}
	
	public void onSelectionChange(MouseEvent event){
		if(event.getSource() instanceof TreeTableView ){
			try {
				@SuppressWarnings("unchecked")
				TreeTableView<Object> tree = (TreeTableView<Object>)event.getSource();
				Object item = tree.getSelectionModel().getSelectedItem().getValue();
				if(item instanceof CertificateBean){
					textArea.setText(item.toString());
				}else{
					textArea1.setText(item.toString());
				}
			} catch (NullPointerException e) {
				System.out.println(e.getMessage());
			}
		}
	}
		
	
	/*****************************************************************************
	 * 																			 *
	 * 																			 *
	 * 							Second Tab Listeners							 *
	 * 																			 *
	 *																			 *
	 *****************************************************************************/
	
	public void onUploadTrustLists(){
		FileChooser chooser = new FileChooser();
		chooser.setTitle("Excel File Location");
		
		chooser.getExtensionFilters().add(
				new ExtensionFilter("XML Document", "*.xml"));
		
		List<File> trustListFiles = chooser.showOpenMultipleDialog(tlGridPane.getScene()
				.getWindow());

		// if null, user clicked cancel so do nothing
		if (trustListFiles == null) {
			return;
		} else {
			for(File file : trustListFiles){
				TrustListBean tl;
				try {
					tl = new TrustListBean(
							CertificateUtilities.getUnmarshalledTrustListFromFile(file));
					
					trustLists.getRoot().getChildren().add(new TreeItem<TrustListBean>(tl));
				} catch (Exception e) {
					String header = "An error occured while uploading trust list:\n"
							+ e.getMessage();
					displayErrorMessage("Upload Error", header, null, e);
				} 
			}
		}
	}
	
	public void onButtonMoveUp1(){
		TreeItem<TrustListBean> item = listOfLists.getSelectionModel().getSelectedItem();
		ObservableList<TreeItem<TrustListBean>> list = 
				listOfLists.getRoot().getChildren();
		
		if(item == null || list == null || list.size() <= 1) return;
		
		int index = list.indexOf(item);
		if(index > 0){
			Collections.swap(list, index, index-1);
			listOfLists.getSelectionModel().clearAndSelect(index-1);
		}
	}
	
	public void onButtonMoveDown1(){
		TreeItem<TrustListBean> item = listOfLists.getSelectionModel().getSelectedItem();
		ObservableList<TreeItem<TrustListBean>> list = 
				listOfLists.getRoot().getChildren();
		
		if(item == null || list == null || list.size() <= 1) return;
		
		int index = list.indexOf(item);
		if(index < list.size() - 1){
			Collections.swap(list, index, index+1);
			listOfLists.getSelectionModel().clearAndSelect(index+1);
		}
	}
	
	public void onAddButtonForTrustList(){
		List<TreeItem<TrustListBean>> list = trustLists.getSelectionModel().getSelectedItems();
		if(list == null || list.size() == 0) return;
		
		listOfLists.getRoot().getChildren().addAll(list);
	}
	
	
	/*****************************************************************************
	 * 																			 *
	 * 																			 *
	 * 						First Tab Helper Methods							 *
	 * 																			 *
	 *																			 *
	 *****************************************************************************/
	
	private void addCertsToTree(List<CertificateBean> certs){
		TreeItem<CertificateBean> root = uploadedCertsTree.getRoot();
		for(CertificateBean bean : certs){
			TreeItem<CertificateBean> parent = new TreeItem<>(bean);
			for(CertificateBean child : bean.getChildrenCerts()){
				parent.getChildren().add(new TreeItem<CertificateBean>(child));
			}
			root.getChildren().add(parent);
		}
	}
	
	private void initializeFirstTabTrees(){
		uploadedCertsTreeCol.setCellValueFactory(new TreeItemPropertyValueFactory<CertificateBean, CertificateBean>("name"));
		tlCertsTreeCol.setCellValueFactory(new TreeItemPropertyValueFactory<CertificateBean, CertificateBean>("name"));
		
		CertificateBean dummyRootCert = new CertificateBean("Uploaded Certificates");
		CertificateBean dummyTLCertRoot = new CertificateBean("TL Certificates");
		TreeItem<CertificateBean> rootUpload = new TreeItem<>(dummyRootCert);
		TreeItem<CertificateBean> rootTL = new TreeItem<>(dummyTLCertRoot);
		uploadedCertsTree.setFixedCellSize(40);
		
		uploadedCertsTreeCol.setCellFactory(new CallbackHandler());
		tlCertsTreeCol.setCellFactory(new CallbackHandler());
		
//		CertificateBean test = new CertificateBean("Test");
//		TreeItem<CertificateBean> bean = new TreeItem<CertificateBean>(test);
//		rootUpload.getChildren().add(bean);
		
		
		
		uploadedCertsTree.setRoot(rootUpload);
		uploadedCertsTree.setShowRoot(false);
		uploadedCertsTree.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		tlCertsTree.setRoot(rootTL);
		tlCertsTree.setShowRoot(false);
		tlCertsTree.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		uploadedCertsTreeCol.setSortable(false);
		tlCertsTreeCol.setSortable(false);
	}
	
	/*****************************************************************************
	 * 																			 *
	 * 																			 *
	 * 						Second Tab Helper Methods							 *
	 * 																			 *
	 *																			 *
	 *****************************************************************************/
	private void initializeSecondTabTrees(){
		trustListsCol.setCellValueFactory(new TreeItemPropertyValueFactory<TrustListBean, CertificateBean>("name"));
		listOfListsCol.setCellValueFactory(new TreeItemPropertyValueFactory<TrustListBean, CertificateBean>("name"));
		
		TrustListBean dummyRootCert = new TrustListBean("Uploaded Trust Lists");
		TrustListBean dummyTLCertRoot = new TrustListBean("TL Certificates");
		TreeItem<TrustListBean> rootUpload = new TreeItem<>(dummyRootCert);
		TreeItem<TrustListBean> rootTL = new TreeItem<>(dummyTLCertRoot);
		
		trustLists.setRoot(rootUpload);
		trustLists.setShowRoot(false);
		trustLists.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		listOfLists.setRoot(rootTL);
		listOfLists.setShowRoot(false);
		listOfLists.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		trustListsCol.setSortable(false);
		listOfListsCol.setSortable(false);
	}
	
	/*****************************************************************************
	 * 																			 *
	 * 																			 *
	 * 								Style Methods							 	 *
	 * 																			 *
	 *																			 *
	 *****************************************************************************/
	
	private void initializeTreeTables(){
		initializeFirstTabTrees();
		initializeSecondTabTrees();
	}
//	
//	private void initializeButtons(){
//		 ImageView up = new ImageView(new Image(getClass().getResourceAsStream(
//					"/resources/up.png")));
//		 up.setFitHeight(15);
//		 up.setFitWidth(15);
//	     upButton.setGraphic(up);
//	     ImageView up1 = new ImageView(new Image(getClass().getResourceAsStream(
//					"/resources/up.png")));
//		 up1.setFitHeight(15);
//		 up1.setFitWidth(15);
//	     upButton1.setGraphic(up1);
//	     
//	     ImageView down = new ImageView(new Image(getClass().getResourceAsStream(
//					"/resources/down.png")));
//		 down.setFitHeight(15);
//		 down.setFitWidth(15);
//	     downButton.setGraphic(down);
//	     ImageView down1 = new ImageView(new Image(getClass().getResourceAsStream(
//					"/resources/down.png")));
//		 down1.setFitHeight(15);
//		 down1.setFitWidth(15);
//	     downButton1.setGraphic(down1);
//	}
	
	private void displayErrorMessage(String title, String header, String content, Exception exp){
		Alert error = new Alert(AlertType.ERROR);
		error.setContentText(content);
		error.setHeaderText(header);
		error.setTitle(title);
		exp.printStackTrace();
		error.showAndWait();
	}
	
	/**
	 * Sets the background image from the image located in the resources folder
	 */
	private void setBackgroundImages() {
		Image logo = new Image(getClass().getResourceAsStream(
				"/resources/background.png"));
		
		BackgroundSize logoSize = new BackgroundSize(600, 400, false, false,
				true, true);
		
		BackgroundImage image = new BackgroundImage(logo,
				BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
				BackgroundPosition.CENTER, logoSize);
		Background background = new Background(image);
		tlGridPane.setBackground(background);
		
		Image logo1 = new Image(getClass().getResourceAsStream(
				"/resources/background2.png"));
		
		BackgroundImage image1 = new BackgroundImage(logo1,
				BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
				BackgroundPosition.CENTER, logoSize);
		
		Background background1 = new Background(image1);
		listOfListGridPane.setBackground(background1);
	}
	
	
	private void setTabPaneBackground(){
//		System.out.println(tabPane.getStyle());
//		tabPane.getStylesheets().add(getClass().getResource("/resources/removeGray.css").toString());
	}
	
	
	/*****************************************************************************
	 * 																			 *
	 * 																			 *
	 * 							Threads/Inner Classes 							 *
	 * 																			 *
	 *																			 *
	 *****************************************************************************/

	
	/**
	 * Listener for saving the preferences when the user closes the GUI using
	 * the mechanism provided by the underlying OS (red "X" at the top right
	 * corner for windows)
	 * 
	 * @author Karottop
	 *
	 */
	public static class OnCloseWindow implements EventHandler<WindowEvent> {

		@Override
		public void handle(WindowEvent event) {
			
			
			
			Platform.exit();
		}

	}
	
	

}
