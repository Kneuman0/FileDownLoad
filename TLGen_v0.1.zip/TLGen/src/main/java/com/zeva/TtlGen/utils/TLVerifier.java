package com.zeva.TtlGen.utils;

import java.io.ByteArrayInputStream;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Iterator;

import javax.xml.bind.DatatypeConverter;
import javax.xml.crypto.MarshalException;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureException;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMValidateContext;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class TLVerifier {
	
	Document doc;
	X509Certificate signingCert;
	
	public TLVerifier(Document doc){
		this.doc = doc;
		
		NodeList sig = doc.getElementsByTagName("ds:Signature");
		for(int i = 0; i < sig.getLength(); i++){
			if(sig.item(i).getNodeType() == Node.ELEMENT_NODE){
				Element el = (Element)sig.item(i);
				
				String begin = "-----BEGIN CERTIFICATE-----\n";
				String end = "\n-----END CERTIFICATE-----";
				String base64Cert = begin + UnmarshalTrustList.getElVal(el, "ds:X509Certificate")
						.replaceAll("[ \t\n]", "") + end;
				
				try {
					CertificateFactory factory = CertificateFactory.getInstance("X.509");
					ByteArrayInputStream in = new ByteArrayInputStream(base64Cert.getBytes());
					this.signingCert = (X509Certificate)factory.generateCertificate(in);
				} catch (CertificateException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
	}
	
	
	@SuppressWarnings("rawtypes")
	public boolean signatureIsValid() throws XMLSignatureException{
		
		NodeList nl = doc.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");
		
		if (nl.getLength() == 0) {
			throw new XMLSignatureException("No XML Digital Signature Found, document is discarded");
		}
		
		String sigValue = "";
		for(int i = 0; i < nl.getLength(); i++){
			if(nl.item(i).getNodeType() == Node.ELEMENT_NODE){
				Element el = (Element)nl.item(i);
				sigValue = UnmarshalTrustList.getElVal(el, "ds:SignatureValue");
			}
		}
		
//		PublicKey publicKey = signingCert.getPublicKey();
		DOMValidateContext valContext = new DOMValidateContext(signingCert.getPublicKey(), nl.item(0));
		XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM");
		XMLSignature signature;
		
		try {
			signature = fac.unmarshalXMLSignature(valContext);
			
			System.out.println("Signature on xml is: " + sigValue.replaceAll("\n", ""));
			String hex = DatatypeConverter.printBase64Binary(signature.getSignatureValue().getValue());
			System.out.println("Signature is: " + hex);
			System.out.println("Signature is equal: " + signature.getSignatureValue().validate(valContext));
			int difference = findDifference(sigValue, hex);
			System.out.println("String1: " + sigValue.substring(difference, sigValue.length()));
			System.out.println("String2: " + hex.substring(difference, hex.length()));
			System.out.println("Difference index: " + difference);
			Iterator itr = signature.getSignedInfo().getReferences().iterator();
			while(itr.hasNext()){
				Reference ref = (Reference)itr.next();
				System.out.println("Reference is passing: " + ref.validate(valContext));
			}
		} catch (MarshalException e) {
			e.printStackTrace();
			throw new XMLSignatureException("Error parsing digital signature: " + e.getMessage());
		}
		
		return signature.validate(valContext);
	}
	
	private int findDifference(String string1, String string2){
		
		for(int i = 0; i < string1.length(); i++){
			if(i == string1.length() - 1 || i == string2.length() - 1) return i;
			
			if(string1.charAt(i) != string2.charAt(i)){
				return i;
			}
		}
		
		return -1;
	}
	
	public boolean isXmlDigitalSignatureValid(Document doc, PublicKey publicKey) throws Exception {
		boolean validFlag = false;
		NodeList nl = doc.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");
		
		if (nl.getLength() == 0) {
			throw new Exception("No XML Digital Signature Found, document is discarded");
		}
		
		DOMValidateContext valContext = new DOMValidateContext(publicKey, nl.item(0));
		XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM");
		XMLSignature signature = fac.unmarshalXMLSignature(valContext);
		validFlag = signature.validate(valContext);
		return validFlag;
	}

}
