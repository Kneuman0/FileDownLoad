package com.zeva.TtlGen.utils;

import java.io.FileInputStream;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.X509Certificate;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;





public class TrustListLibTest {

	public static void main(String[] args) throws Exception {
//		KeyPairGenerator keyPairGenerator = KeyPairGenerator
//		        .getInstance("RSA");
//	    keyPairGenerator.initialize(2048);
//	    KeyPair keyPair = keyPairGenerator.generateKeyPair();
//	    PublicKey publicKey = keyPair.getPublic();
//	    PrivateKey privateKey = keyPair.getPrivate();
//	    X509Certificate selfCert = CertificateUtilities.createCertificate(
//	    		"CN=Trans Sped SAFE CA III","CN=SAFE Bridge CA 02", publicKey, privateKey);
//	    CertificateUtilities.inputPrivateKeyAndCert("password", "newKey", "newCert", selfCert, privateKey);
		
//		System.out.println(CertificateUtilities.getPrivateKey("password", "newKey").getAlgorithm());
		
//		System.out.println(CertificateUtilities.getCertificate("myName", "password"));
		
		
		PrivateKey key = CertificateUtilities.getPrivateKey("password", "newKey");
		System.out.println(key.getAlgorithm());
		X509Certificate cert = CertificateUtilities.getCertificate("newCert", "password");
		TrustListXMLPrinter printer = new TrustListXMLPrinter(key, cert);
//		sign.signDocument(key, cert);
		printer.signAndPrint("TestXML.xml");
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse(new FileInputStream("TestXML.xml"), "UTF-8");
		
		doc.normalize();
		TLVerifier verify = new TLVerifier(doc);
		System.out.println(verify.signatureIsValid());
//		System.out.println(verify.isXmlDigitalSignatureValid(doc, publicKey));
	}
	


}
