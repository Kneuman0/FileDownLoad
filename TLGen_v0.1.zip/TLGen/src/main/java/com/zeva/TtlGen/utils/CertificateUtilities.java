package com.zeva.TtlGen.utils;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.xml.bind.DatatypeConverter;
import javax.xml.crypto.dsig.XMLSignatureException;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.cert.X509v3CertificateBuilder;
import org.bouncycastle.cert.jcajce.JcaX509ExtensionUtils;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

import sun.misc.BASE64Encoder;
import javafx.scene.control.TreeItem;
import javafx.stage.FileChooser.ExtensionFilter;

import com.zeva.temp.dataModellib.AddressBean;
import com.zeva.temp.dataModellib.OtherTSLPointer;
import com.zeva.temp.dataModellib.ProviderList;
import com.zeva.temp.dataModellib.ServiceBean;
import com.zeva.temp.dataModellib.StatusInformationBean;
import com.zeva.temp.dataModellib.TrustList;
import com.zeva.tlGen.dataModel.CertificateBean;

public class CertificateUtilities {

	public static List<CertificateBean> getSampleCerts() {
		List<CertificateBean> things = new ArrayList<CertificateBean>();
		things.add(new CertificateBean());
		things.add(new CertificateBean());
		CertificateBean bean = new CertificateBean();
		bean.setChildrenCerts(things);
		things.add(bean);
		return things;
	}

	public static void deleteSelectedItems(List<TreeItem<Object>> all,
			List<TreeItem<Object>> selected) {
		for (int i = selected.size() - 1; i >= 0; i--) {
			all.remove(selected.get(i));
		}
	}
	
	public static void exportTL(String password, TrustList tl, File certFile) throws IOException{
		PrivateKey priv = getPrivateKey(password, "newKey");
		X509Certificate cert = getCertificate("newCert", password);
		TrustListXMLPrinter printer = new TrustListXMLPrinter(tl, priv, cert);
		printer.signAndPrint(certFile.getAbsolutePath());
	}
	
	public static PrivateKey getPrivateKey(String password, String alias){
		PrivateKey privKey = null;
		try {
			String storeName = "KeyStore.jks";
		    
		    KeyStore inStore = KeyStore.getInstance("PKCS12");
		    inStore.load(new FileInputStream(storeName), password.toCharArray());
		    privKey = (PrivateKey)inStore.getKey(alias, password.toCharArray());
		  } catch (Exception e) {
		    e.printStackTrace();
		    throw new AssertionError(e.getMessage());
		  }
		return privKey;
	}
	
	public static X509Certificate getCertificate(String alias, String password){
		String storeName = "KeyStore.jks";
		X509Certificate cert = null;
		
		try {
			KeyStore outStore = KeyStore.getInstance("PKCS12");
			InputStream stream = new FileInputStream(storeName);
			outStore.load(stream, password.toCharArray());
			cert = (X509Certificate)outStore.getCertificate(alias);
			stream.close();
		} catch (KeyStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CertificateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return cert;
	}
	
	public static void inputPrivateKeyAndCert(String password, String keyAlias,
			String certAlias, X509Certificate cert, PrivateKey key){
		try {
			String storeName = "KeyStore.jks";

		    // Note: if you just want to store this certificate then write the
		    // contents of selfCert.getEncoded() to file

		    Certificate[] outChain = { cert };
		    InputStream stream = new FileInputStream(storeName);
		    KeyStore outStore = KeyStore.getInstance("PKCS12");
		    outStore.load(stream, password.toCharArray());
		    outStore.setKeyEntry(keyAlias, key, password.toCharArray(),
		        outChain);
		    outStore.setCertificateEntry(certAlias, cert);
		    stream.close();
		    OutputStream outputStream = new FileOutputStream(storeName);
		    outStore.store(outputStream, password.toCharArray());
		    outputStream.flush();
		    outputStream.close();
	 	} catch (Exception e) {
		    e.printStackTrace();
		    throw new AssertionError(e.getMessage());
		}
	}
	
	public static void inputCertificate(X509Certificate cert, String password, String alias){
		try{
			String storeName = "KeyStore.jks";
			KeyStore outStore = KeyStore.getInstance("PKCS12");
			InputStream stream = new FileInputStream(storeName);
		    outStore.load(stream, password.toCharArray());
		    outStore.setCertificateEntry(alias, cert);
		    stream.close();
		    
		    OutputStream outputStream = new FileOutputStream(storeName);
		    outStore.store(outputStream, password.toCharArray());
		    outputStream.flush();
		    outputStream.close();
		} catch (Exception e) {
		    e.printStackTrace();
		    throw new AssertionError(e.getMessage());
		}
	}

	public static List<ExtensionFilter> getSupportedExtFilters() {
		List<ExtensionFilter> filters = new ArrayList<>();
		filters.add(new ExtensionFilter("All Supported Certificates", "*.pem",
				"*.cer"));
		filters.add(new ExtensionFilter("Privacy Enhanced Mail", "*.pem"));
		filters.add(new ExtensionFilter("Security Certificate", "*.cer"));
		return filters;
	}

	public static TrustList buildTrustList(List<CertificateBean> beans,
			Properties settings) {
		TrustList tl = new TrustList();
		tl.setDs(settings.getProperty("ds"));
		tl.setId(settings.getProperty("Id"));
		tl.setSchemaLocation(settings.getProperty("schemaLocation"));
		tl.setXAdES(settings.getProperty("XAdES"));
		tl.setXsi(settings.getProperty("xsi"));
		tl.setStatusInfo(getStatusInfoBean(settings));
		tl.setTSLTag(settings.getProperty("TSLTag"));
		tl.setTsl(settings.getProperty("tsl"));
		tl.setTsps(getTSPs(beans, settings));

		return tl;
	}

	public static TrustList buildTrustList(List<CertificateBean> beans) {
		Properties settings = new Properties();
		try (FileInputStream stream = new FileInputStream("props.settings")) {
			settings.load(stream);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return buildTrustList(beans, settings);
	}

	public static StatusInformationBean getStatusInfoBean(Properties props) {
		StatusInformationBean infoBean = new StatusInformationBean();
		infoBean.setAddress(new AddressBean(props
				.getProperty("SchemeOperatorAddressPostal"), props
				.getProperty("SchemeOperatorAddressElectronic")));
		// need to generate
		// infoBean.setListIssueDateTime(listIssueDateTime);
		// infoBean.setNextUpdate(nextUpdate);
		infoBean.setHistoricalInformationPeriod(props
				.getProperty("HistoricalInformationPeriod"));
		infoBean.setPointers(getPointers(props
				.getProperty("TextualInformation")));
		infoBean.setPolicyOrLegalNotice(props
				.getProperty("PolicyOrLegalNotice"));
		infoBean.setSchemeInformationURI(props
				.getProperty("SchemeInformationURI"));
		infoBean.setSchemeName(props.getProperty("SchemeName"));
		infoBean.setSchemeOperatorName(props.getProperty("SchemeOperatorName"));
		infoBean.setSchemeTerritory(props.getProperty("SchemeTerritory"));
		infoBean.setSchemeTypeCommunityRules(props
				.getProperty("SchemeTypeCommunityRules"));
		infoBean.setStatusDeterminationApproach(props
				.getProperty("StatusDeterminationApproach"));
		infoBean.setTslSequenceNumber(props.getProperty("TSLSequenceNumber"));
		infoBean.setTslType(props.getProperty("TSLType"));
		infoBean.setTslVersionIdentifier(props
				.getProperty("TSLVersionIdentifier"));

		return infoBean;
	}

	public static List<ProviderList> getTSPs(List<CertificateBean> certs,
			Properties props) {
		List<ProviderList> provs = new ArrayList<>();
		ProviderList prov = new ProviderList();
		provs.add(prov);
		prov.setAddress(new AddressBean(props.getProperty("TSPAddressPostal"),
				props.getProperty("TSPAddressElectronic")));
		prov.setLanguage(props.getProperty("TSPNameLang"));
		prov.setName(props.getProperty("TSPName"));
		prov.setTspInformationURI(props.getProperty("TSPInformationURI"));
		prov.setTspServices(getServiceBeans(certs, props));

		return provs;
	}

	public static List<OtherTSLPointer> getPointers(String value) {
		List<OtherTSLPointer> pointers = new ArrayList<>();
		for (String pointer : value.split(";"))
			pointers.add(new OtherTSLPointer(pointer));

		return pointers;
	}

	public static List<ServiceBean> getServiceBeans(
			List<CertificateBean> certs, Properties props) {
		List<ServiceBean> services = new ArrayList<>();
		for (CertificateBean cert : certs) {
			ServiceBean bean = new ServiceBean(cert);
			bean.setLanguage(props.getProperty("serivceLang"));
			services.add(new ServiceBean(cert));
		}

		return services;
	}

	public static String generateX509SKI(X509Certificate cert) {
		JcaX509ExtensionUtils util = null;
		try {
			util = new JcaX509ExtensionUtils();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		byte[] array = util.createSubjectKeyIdentifier(cert.getPublicKey()).getKeyIdentifier();
		
		return DatatypeConverter.printHexBinary(array);
	}

	public static void exportNodesToPem(List<TreeItem<CertificateBean>> nodes,
			File location) throws CertificateEncodingException, IOException {
		List<X509Certificate> certs = new ArrayList<>();
		for (TreeItem<CertificateBean> node : nodes)
			certs.add(node.getValue().getParentCert());

		exportCertsToPem(certs, location);

	}

	public static List<CertificateBean> getUnmarshalledCertsFromTL(File location)
			throws Exception {
		UnmarshalTrustList um = new UnmarshalTrustList(location, false);
		List<ServiceBean> services = um.getServiceBeans();
		List<CertificateBean> certs = new ArrayList<>();
		for (ServiceBean service : services) {
			certs.add(new CertificateBean(service.getX509Certificate()));
		}
		
		um.dispose();

		return certs;
	}

	public static TrustList getUnmarshalledTrustListFromFile(File location)
			throws Exception {
		UnmarshalTrustList um;
		try {
			um = new UnmarshalTrustList(location, false);
		} catch (XMLSignatureException sigError){
			throw new Exception("Invalid Signature");
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return um.getTrustList();
	}

	public static void exportCertsToPem(List<X509Certificate> certs,
			File location) throws CertificateEncodingException, IOException {

		List<String> encodedCerts = new ArrayList<>();
		for (X509Certificate cert : certs) {
			byte[] binary = cert.getEncoded();
			String base64 = DatatypeConverter.printBase64Binary(binary);
			String formatedBase64 = insertPeriodically(
					base64.replaceAll("\r", ""), "\r", 65);
			String begin = "-----BEGIN CERTIFICATE-----\n";
			String end = "\n-----END CERTIFICATE-----";
			encodedCerts.add(begin + formatedBase64 + end);
		}

		PrintWriter writer = new PrintWriter(new FileWriter(location));
		for (String formattedCert : encodedCerts) {
			writer.println(formattedCert);
		}
		writer.close();
	}

	public static String insertPeriodically(String text, String insert,
			int period) {
		StringBuilder builder = new StringBuilder(text.length()
				+ insert.length() * (text.length() / period) + 1);

		int index = 0;
		String prefix = "";
		while (index < text.length()) {
			// Don't put the insert in the very first iteration.
			// This is easier than appending it *after* each substring
			builder.append(prefix);
			prefix = insert;
			builder.append(text.substring(index,
					Math.min(index + period, text.length())));
			index += period;
		}
		return builder.toString();
	}
	
	public static X509Certificate createCertificate(String dn, String issuer,
	        PublicKey publicKey, PrivateKey privateKey) throws Exception {
		X500Name iss = new X500Name(issuer);
		X500Name DN = new X500Name(dn);
		ContentSigner sigGen = new JcaContentSignerBuilder("SHA1withRSA").build(privateKey);
		SubjectPublicKeyInfo info = SubjectPublicKeyInfo.getInstance(publicKey.getEncoded());
	    X509v3CertificateBuilder certGenerator = new X509v3CertificateBuilder(
	    		iss, new BigInteger("1"), new Date(), new Date(), DN, info);
	    
	    CertificateFactory fact = CertificateFactory.getInstance("X.509");
	    ByteArrayInputStream in = new ByteArrayInputStream(certGenerator.build(sigGen).getEncoded());
	    return (X509Certificate)fact.generateCertificate(in);
	}
	
	public static X509Certificate getCertWithoutLineBreaks(X509Certificate cert){
		X509Certificate newCert = null;
		try {
			BASE64Encoder encoder = new BASE64Encoder();
			String base64 = encoder.encode(cert.getEncoded()).replaceAll("[ \n\t\r]", "");
			String begin = "-----BEGIN CERTIFICATE-----\n";
			String end = "\n-----END CERTIFICATE-----";
			String total = begin + base64 + end;
			CertificateFactory factory = CertificateFactory.getInstance("X.509");
			ByteArrayInputStream input = new ByteArrayInputStream(total.getBytes());
			newCert = (X509Certificate)factory.generateCertificate(input);
		} catch (CertificateEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CertificateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return newCert;
	}
	
	
	
	
}
