package com.zeva.TtlGen.utils;

import java.io.File;
import java.io.IOException;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;

import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.spec.XPathFilterParameterSpec;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

import com.zeva.temp.dataModellib.TrustListofLists;
import com.zeva.temp.dataModellib.TrustList;

public class TrustListXMLPrinter {
	private Document doc;
	private X509Certificate cert;
	private PrivateKey key;
	
	public TrustListXMLPrinter(TrustList list, PrivateKey key, X509Certificate cert) {
		this.key = key;
		this.cert = cert;
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			DocumentBuilder builder = factory.newDocumentBuilder();
			doc = builder.newDocument();
			doc.setXmlVersion("1.0");
			doc.setXmlStandalone(true);
		} catch (DOMException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
		
		buildDocument(list);
	}
	
	public TrustListXMLPrinter(TrustListofLists listsOfLists, PrivateKey key, X509Certificate cert){
		
		
		buildDocument(listsOfLists);
	}
	
	// Strictly for testing
	public TrustListXMLPrinter(PrivateKey key, X509Certificate cert){
		this.key = key;
		this.cert = cert;
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			DocumentBuilder builder = factory.newDocumentBuilder();
			doc = builder.newDocument();
			doc.setXmlVersion("1.0");
			doc.setXmlStandalone(true);
		} catch (DOMException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
		Element rootElement = doc.createElement("TrustServiceStatusList");
		Element sub = doc.createElement("TestMe");
		sub.setTextContent("Things");
		rootElement.appendChild(sub);
		doc.appendChild(rootElement);
	}
	
	private void buildDocument(TrustListofLists listOfLists){
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			doc = builder.newDocument();
		} catch (DOMException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
		
		
	}
	
	private void buildDocument(TrustList tl){
		MarshalTrustList buildTL = new MarshalTrustList(doc);
		buildTL.marshalTrustList(tl);
	}
	
	public Document getDoc(){
		return this.doc;
	}
	
	public void signAndPrint(String absolutePath) throws IOException{
		try {
			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty(OutputKeys.METHOD, "xml");
			transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
			transformer.setOutputProperty(OutputKeys.STANDALONE, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "8");
			
			TLSigner signer = new TLSigner(doc);
			signer.signDocument(key, cert);
			
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(absolutePath));
			transformer.transform(source, result);
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

}
