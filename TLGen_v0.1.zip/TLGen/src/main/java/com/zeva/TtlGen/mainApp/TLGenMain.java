package com.zeva.TtlGen.mainApp;

import com.sun.javafx.application.LauncherImpl;
import com.zeva.tlGen.controllers.SplashScreen;

public class TLGenMain {

	public static void main(String[] args) {

		LauncherImpl.launchApplication(TLMainLauncher.class, SplashScreen.class, args);
		
	}

}
