package com.zeva.TtlGen.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.security.cert.CertificateException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.crypto.dsig.XMLSignatureException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.zeva.temp.dataModellib.AddressBean;
import com.zeva.temp.dataModellib.ElectronicAddressBean;
import com.zeva.temp.dataModellib.OtherTSLPointer;
import com.zeva.temp.dataModellib.PhysicalAddressBean;
import com.zeva.temp.dataModellib.ProviderList;
import com.zeva.temp.dataModellib.ServiceBean;
import com.zeva.temp.dataModellib.StatusInformationBean;
import com.zeva.temp.dataModellib.TrustList;

public class UnmarshalTrustList {
	private Document doc;
	
	public static final DateTimeFormatter dateFormatter = DateTimeFormatter.ISO_DATE_TIME;
	
	public UnmarshalTrustList(File file, boolean doVerify) throws ParserConfigurationException, FileNotFoundException, SAXException, IOException, XMLSignatureException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder builder = factory.newDocumentBuilder();
		doc = builder.parse(new FileInputStream(file), "UTF-8");
		
		doc.normalize();
		if(!doVerify){
			TLVerifier verifier = new TLVerifier(doc);
			if(!verifier.signatureIsValid()){
				throw new XMLSignatureException("Signature Invalid!");
			}
		}
		
		
	}
	
	public List<OtherTSLPointer> getOtherTSLPointers(){
		NodeList nList = doc.getElementsByTagName("tsl:PointersToOtherTSL");
		List<OtherTSLPointer> pointers = new ArrayList<>();
		
		for(int i = 0; i < nList.getLength(); i++){
			if(nList.item(i).getNodeType() == Node.ELEMENT_NODE){
				Element el = (Element)nList.item(i);
				pointers.add(new OtherTSLPointer(fix(el.getElementsByTagName(
						"tsl:TextualInformation").item(0).getTextContent())));
			}
		}
		
		return pointers;
		
	}
	
	public List<ServiceBean> getServiceBeans() throws CertificateException{
		NodeList nList = doc.getElementsByTagName("tsl:ServiceInformation");
		List<ServiceBean> services = new ArrayList<>();
		
		for(int i = 0; i < nList.getLength(); i++){
			if(nList.item(i).getNodeType() == Node.ELEMENT_NODE){
				Element el = (Element)nList.item(i);
				ServiceBean service = new ServiceBean();
				
				service.setServiceTypeIdentifier(getElVal(el, "tsl:ServiceTypeIdentifier"));
				
				service.setServiceName(getElVal(el, "tsl:Name"));
				
				service.setLanguage(getLang());
				
				String begin = "-----BEGIN CERTIFICATE-----\n";
				String end = "\n-----END CERTIFICATE-----";
				String base64Cert = begin + getElVal(el, "tsl:X509Certificate")
						.replaceAll("[ \t\n]", "") + end;
				
				service.setBase64Cert(base64Cert);
									
				service.setX509Certificate(base64Cert.getBytes());
				
				service.setX509SKI(getElVal(el, "tsl:X509SKI"));
				
				service.setX509SubjectName(getElVal(el, "tsl:X509SubjectName"));
				
				service.setKeyValue(getElVal(el, "ds:KeyValue"));
				
				service.setServiceStatus(getElVal(el, "tsl:ServiceStatus"));
				
				service.setExtension(getElVal(el, "tsl:Extension"));
				
				service.setStatusStartingTime(ZonedDateTime.parse(
						getElVal(el, "tsl:StatusStartingTime"), dateFormatter));
				
				services.add(service);
			// end of if	
			}
		// end of for loop
		}
		
		return services;
	}
	
	public StatusInformationBean getStatusInformationBean() throws DOMException, URISyntaxException{
		NodeList nList = doc.getElementsByTagName("tsl:SchemeInformation");
		StatusInformationBean status = new StatusInformationBean();
		
		for(int i = 0; i < nList.getLength(); i++){
			if(nList.item(i).getNodeType() == Node.ELEMENT_NODE){
				Element el = (Element)nList.item(i);
				
				status.setTslVersionIdentifier(getElVal(el, "tsl:TSLVersionIdentifier"));
				
				status.setTslSequenceNumber(getElVal(el, "tsl:TSLSequenceNumber"));
				
				status.setTslType(getElVal(el, "tsl:TSLType"));
				
				status.setSchemeOperatorName(getElVal(el, "tsl:SchemeOperatorName"));
				
				status.setAddress(getAddressBean("tsl:SchemeOperatorAddress"));
				
				status.setSchemeName(getElVal(el, "tsl:SchemeName"));
				
				status.setSchemeInformationURI(getElVal(el, "tsl:SchemeInformationURI"));
				
				status.setStatusDeterminationApproach(getElVal(el, "tsl:StatusDeterminationApproach"));
				
				status.setSchemeTerritory(getElVal(el, "tsl:SchemeTerritory"));
				
				status.setSchemeTypeCommunityRules(getElVal(el, "tsl:SchemeTypeCommunityRules"));
				
				status.setPolicyOrLegalNotice(getElVal(el, "tsl:PolicyOrLegalNotice"));
				
				status.setHistoricalInformationPeriod(
						getElVal(el, "tsl:HistoricalInformationPeriod"));
				
				status.setPointers(getOtherTSLPointers());
				
				status.setListIssueDateTime(ZonedDateTime.parse(
						getElVal(el, "tsl:ListIssueDateTime"), dateFormatter));
				
				status.setNextUpdate(ZonedDateTime.parse(
						getElVal(el, "tsl:dateTime"), dateFormatter));
					
			// end of if
			}
		// end of for loop
		}
		
		return status;
	}
	
	public AddressBean getAddressBean(String tagName) throws DOMException, URISyntaxException{
		AddressBean addresses = new AddressBean();
		NodeList nList = doc.getElementsByTagName(tagName);
		
		for(int i = 0; i < nList.getLength(); i++){
			if(nList.item(i).getNodeType() == Node.ELEMENT_NODE){
				Element el = (Element)nList.item(i);
		
				PhysicalAddressBean address = new PhysicalAddressBean();
				
				address.setStreetAddress(getElVal(el, "tsl:StreetAddress"));
				
				address.setLocality(getElVal(el, "tsl:Locality"));
				
				address.setPostalCode(getElVal(el, "tsl:PostalCode"));
				
				address.setCountryName(getElVal(el, "tsl:CountryName"));
				
				addresses.addPhysAddress(address);
			}
		}
		
		for(int i = 0; i < nList.getLength(); i++){
			if(nList.item(i).getNodeType() == Node.ELEMENT_NODE){
				
				Element el = (Element)nList.item(i);
				
				ElectronicAddressBean elecAdd = new ElectronicAddressBean();
				elecAdd.setUri(getElVal(el, "tsl:URI"));
				
				addresses.addElecAddress(elecAdd);				
			}
		}
		
		return addresses;
	}
	
	public List<ProviderList> getProviderList() throws DOMException, URISyntaxException, CertificateException{
		NodeList nList = doc.getElementsByTagName("tsl:TrustServiceProvider");
		List<ProviderList> providers = new ArrayList<>();
		
		for(int i = 0; i < nList.getLength(); i++){
			if(nList.item(i).getNodeType() == Node.ELEMENT_NODE){
				Element el = (Element)nList.item(i);
				ProviderList providerList = new ProviderList();
			
				providerList.setName(getElVal(el, "tsl:Name"));
				
				providerList.setLanguage(getLang());
				
				providerList.setAddress(getAddressBean("tsl:TSPAddress"));
				
				providerList.setTspInformationURI(getElVal(el, "tsl:TSPInformationURI"));
				
				providerList.setTspServices(getServiceBeans());
				
				providers.add(providerList);
				
			// end of if	
			}
		// end of for loop
		}
		
		return providers;
	}
	
	public TrustList getTrustList() throws DOMException, URISyntaxException, CertificateException{
		NodeList nList = doc.getElementsByTagName("tsl:TrustServiceStatusList");
		TrustList tl = new TrustList();
		
		for(int i = 0; i < nList.getLength(); i++){
			if(nList.item(i).getNodeType() == Node.ELEMENT_NODE){
				Element el = (Element)nList.item(i);
				
				tl.setTsl(el.getAttribute("xmlns:tsl"));
				
				tl.setXAdES(el.getAttribute("xmlns:XAdES"));
				
				tl.setDs(el.getAttribute("xmlns:ds"));
				
				tl.setXsi(el.getAttribute("xmlns:xsi"));
				
				tl.setSchemaLocation(el.getAttribute("xsi:schemaLocation"));
				
				tl.setTSLTag(el.getAttribute("TSLTag"));
				
				tl.setId(el.getAttribute("Id"));
				
				tl.setStatusInfo(getStatusInformationBean());
				tl.setTsps(getProviderList());
			}
		}
		
		tl.setStatusInfo(getStatusInformationBean());
		tl.setTsps(getProviderList());
		return tl;
	}
	
	private static String fix(String text){
		return text == null ? null : text.replace("Node", "");
	}
	
	private String getLang(){
		NodeList nList = doc.getElementsByTagName("tsl:Name");
		
		for(int i = 0; i < nList.getLength(); i++){
			if(nList.item(i).getNodeType() == Node.ELEMENT_NODE){
				Element el = (Element)nList.item(i);
				return fix(el.getAttribute("xml:lang"));
			}
		}
		
		return null;
		
	}
	
	public static String getElVal(Element parent, String elementName){
		String unMarshalledText = null;
		try{
			unMarshalledText = fix(parent.getElementsByTagName(elementName)
					.item(0).getTextContent());
		} catch(NullPointerException e){
			e.printStackTrace();
		}
		
		return unMarshalledText;
	}
	
	public void dispose(){
		doc = null;
	}
	
	
	

}
