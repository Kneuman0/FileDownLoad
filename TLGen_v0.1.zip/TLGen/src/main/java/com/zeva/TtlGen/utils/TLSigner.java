package com.zeva.TtlGen.utils;

import java.lang.reflect.Field;
import java.security.InvalidAlgorithmParameterException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.crypto.MarshalException;
import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLObject;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureException;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.crypto.dsig.spec.SignatureMethodParameterSpec;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;
import javax.xml.crypto.dsig.spec.XPathFilter2ParameterSpec;
import javax.xml.crypto.dsig.spec.XPathFilterParameterSpec;
import javax.xml.crypto.dsig.Reference;

import org.w3c.dom.Document;

import com.sun.org.apache.xml.internal.security.utils.XMLUtils;

public class TLSigner {
	
	private XMLSignatureFactory sigFact;
	private List<Reference> refs;
	private Document doc;
	
		
	public TLSigner(Document doc){
		this.doc = doc;
		sigFact = XMLSignatureFactory.getInstance("DOM");
		refs = new ArrayList<>();
		List<String> params = new ArrayList<>();
		params.add("/translate(.,'-', '')");
		try {
			List<Transform> transforms = new ArrayList<Transform>();
			transforms.add(sigFact.newTransform("http://www.w3.org/2001/10/xml-exc-c14n#", (TransformParameterSpec) null));
			transforms.add(sigFact.newTransform(Transform.XPATH, 
					new XPathFilterParameterSpec("normalize-space() and not(ancestor-or-self::ds:Signature)")));
//			sigFact.  and translate() "normalize-space() and translate(., '&#xA;', '') and not(ancestor-or-self::ds:Signature)"
			transforms.add(sigFact.newTransform(Transform.ENVELOPED, (TransformParameterSpec) null));
			DigestMethod method = sigFact.newDigestMethod(DigestMethod.SHA256, null);
			Reference ref = sigFact.newReference("", method, transforms, "", "");
			refs.add(ref);
		} catch (NoSuchAlgorithmException | InvalidAlgorithmParameterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private SignedInfo getSignedInfo(){
		SignedInfo info = null;
		try {
			CanonicalizationMethod can = sigFact.newCanonicalizationMethod(
//					CanonicalizationMethod.XPATH
					"http://www.w3.org/2001/10/xml-exc-c14n#"
					, (C14NMethodParameterSpec)null);
//					(C14NMethodParameterSpec)null);
			SignatureMethod sigMeth = sigFact.newSignatureMethod(SignatureMethod.RSA_SHA1
//					"http://www.w3.org/2001/04/xmldsig-more#rsa-sha256"
					, (SignatureMethodParameterSpec)null);
			info = sigFact.newSignedInfo(can, sigMeth, refs);
		} catch (NoSuchAlgorithmException | InvalidAlgorithmParameterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return info;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private KeyInfo getKeyInfo(X509Certificate cert){
		// Create the KeyInfo containing the X509Data.
        KeyInfoFactory kif = sigFact.getKeyInfoFactory();
        List x509Content = new ArrayList();
        x509Content.add(cert.getSubjectX500Principal().getName());
        x509Content.add(cert);
        X509Data xd = kif.newX509Data(x509Content);
        KeyInfo ki = kif.newKeyInfo(Collections.singletonList(xd));
        
        return ki;
	}
	
	public void signDocument(PrivateKey key, X509Certificate cert){
		
		try {
			Field f;
			try {
				f = XMLUtils.class.getDeclaredField("ignoreLineBreaks");
				f.setAccessible(true);
				f.set(null, Boolean.TRUE);
			} catch (NoSuchFieldException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			// Create a DOMSignContext and specify the RSA PrivateKey and
	        // location of the resulting XMLSignature's parent element.
	        DOMSignContext dsc = new DOMSignContext(key, doc.getDocumentElement());
	        dsc.setDefaultNamespacePrefix("ds");
			XMLSignature sig = sigFact.newXMLSignature(getSignedInfo(), getKeyInfo(cert));
			sig.sign(dsc);
			
		} catch (MarshalException | XMLSignatureException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}
		
	}
	
	public class XMLObjectBean implements XMLObject{

		@Override
		public boolean isFeatureSupported(String feature) {
			// TODO Auto-generated method stub
			return false;
		}

		@SuppressWarnings("rawtypes")
		@Override
		public List getContent() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public String getId() {
			return "xades-id-2938f854faa4e86744a696771157ed8c";
		}

		@Override
		public String getMimeType() {
			// TODO Auto-generated method stub
			return "text/xml";
		}

		@Override
		public String getEncoding() {
			// TODO Auto-generated method stub
			return "UTF-8";
		}
		
	}
	
	
	/**
	 * Strictly a test method
	 * @param cert
	 * @param privateKey
	 */
	public void generateXMLDigitalSignature(X509Certificate cert, PrivateKey privateKey) {
				//Create XML Signature Factory
				XMLSignatureFactory xmlSigFactory = XMLSignatureFactory.getInstance("DOM");
				DOMSignContext domSignCtx = new DOMSignContext(privateKey, doc.getDocumentElement());
				Reference ref = null;
				SignedInfo signedInfo = null;
				
				try {
					ref = xmlSigFactory.newReference("", xmlSigFactory.newDigestMethod(DigestMethod.SHA1, null),
					Collections.singletonList(xmlSigFactory.newTransform(Transform.ENVELOPED,
					(TransformParameterSpec) null)), null, null);
					signedInfo = xmlSigFactory.newSignedInfo(
					xmlSigFactory.newCanonicalizationMethod(CanonicalizationMethod.INCLUSIVE,
					(C14NMethodParameterSpec) null),
					xmlSigFactory.newSignatureMethod(SignatureMethod.RSA_SHA1, null),
					Collections.singletonList(ref));
				} catch (NoSuchAlgorithmException ex) {
					ex.printStackTrace();
				} catch (InvalidAlgorithmParameterException ex) {
					ex.printStackTrace();
				}
				//Pass the Public Key File Path
				KeyInfo keyInfo = getKeyInfo(cert);
				//Create a new XML Signature
				XMLSignature xmlSignature = xmlSigFactory.newXMLSignature(signedInfo, keyInfo);
				try {
					//Sign the document
					xmlSignature.sign(domSignCtx);
				} catch (MarshalException ex) {
					ex.printStackTrace();
				} catch (XMLSignatureException ex) {
					ex.printStackTrace();
				}
	}
	
	// using if pre-calculated digest value needs to be calculated
//	private List<Reference> getReferences() throws NoSuchAlgorithmException, InvalidAlgorithmParameterException{
//				
//		Transform transform = sigFact.newTransform("http://www.w3.org/2001/10/xml-exc-c14n#", (TransformParameterSpec) null);
//		Reference ref2 = sigFact.newReference("#xades-id-2938f854faa4e86744a696771157ed8c", method, transforms, "http://uri.etsi.org/01903#SignedProperties", "");
//		
//		return transforms;
//	}
	
	
	
	
	
}
